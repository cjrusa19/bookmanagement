package com.books.bookmanagement.service;

import java.util.Date;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.books.bookmanagement.domain.Book;
import com.books.bookmanagement.exception.BusinessException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookManagementServiceTest {

	@Autowired
	IBookManagementService bookManagementService;

	@Test
	void testGetAllBooks() {
		try {
			this.bookManagementService.getAllBooks();
		} catch (BusinessException e) {
			Assert.assertEquals(e.getMessage(), "error.books.notavailable");
		}
	}

	@Test
	void testGetBookByISBN() {
		try {
			this.bookManagementService.getBookByISBN("123");
		} catch (BusinessException e) {
			Assert.assertEquals(e.getMessage(), "error.nobook.exist");
		}
	}

	@Test
	void testSaveBook() throws BusinessException {
		Book book = new Book();
		book.setAuthor("Jyothsna");
		book.setTitle("Spring Boot");
		book.setDatePublished(new Date());
		book.setIsbn("111");
		book.setRate(5);
		Book book2 = this.bookManagementService.saveBook(book);
		Assert.assertNotNull(book2);

	}
}
