package com.books.bookmanagement.exception;

// TODO: Auto-generated Javadoc
/**
 * The Class BusinessException.
 */
public class BusinessException  extends Exception  {  
   
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5530647942446258011L;
	
	/** The message. */
	private  String message;
	
	/** The args. */
	private  Object[] args;

	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 */
	public BusinessException (final String message)  
    {  
		super(message);  
        this.message = message;
    }  
	
	/**
	 * Instantiates a new business exception.
	 *
	 * @param message the message
	 * @param args the args
	 */
	public BusinessException (final String message, final Object[] args)  
    {  
		super(message);  
		this.message = message;
        this.args = args;
    }

	
	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Gets the args.
	 *
	 * @return the args
	 */
	public Object[] getArgs() {
		return args;
	}

	/**
	 * Sets the args.
	 *
	 * @param args the new args
	 */
	public void setArgs(Object[] args) {
		this.args = args;
	} 
}  