package com.books.bookmanagement.mapper;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections.CollectionUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Component;
import com.books.bookmanagement.domain.BaseDomain;
import com.books.bookmanagement.entity.BasePO;

@Component
public class DafaultDozerMapper {
	private DozerBeanMapper mapper;
	public DafaultDozerMapper() {
		this.mapper = new DozerBeanMapper();
		this.mapper.setMappingFiles(Collections.singletonList("dozer_mapping\\default-mapper.xml"));
	}
	
	public  <T> T mapBoToPo(BaseDomain bo, Class<? extends BasePO> basePOClass){
		if(bo!=null) {
		return (T) this.mapper.map(bo,basePOClass);
		}
		return null;
	}
	
	public <T> T  mapPoToBo(BasePO po, Class<? extends BaseDomain> baseDomainClass){
		if(po!=null) {
			return (T) this.mapper.map(po,baseDomainClass);
		}
		return null;
	}
	
	public List<? extends BaseDomain> mapPoToBoList(List<? extends BasePO> poList, Class<? extends BaseDomain> baseDomainClass){
		List<BaseDomain> result = null;
		if(CollectionUtils.isNotEmpty(poList)) {
			result = poList.stream().map(e->this.mapper.map(e, baseDomainClass)).collect(Collectors.toList());
		}
		return result;
	}

}
