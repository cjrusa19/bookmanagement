package com.books.bookmanagement.error.domain;

import java.io.Serializable;

public class Violation implements Serializable {

	
	private static final long serialVersionUID = -5464806356718221655L;

	private String fieldName;

	private String message;
	Violation(){
		
	}
	public Violation(String fieldName,String message){
		this();
		this.fieldName=fieldName;
		this.message = message;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}