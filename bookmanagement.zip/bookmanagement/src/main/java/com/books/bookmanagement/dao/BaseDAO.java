package com.books.bookmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.books.bookmanagement.entity.BookPO;
@Repository
public interface BaseDAO extends JpaRepository<BookPO,Long> {
	   //We can define any common methods which are required for entire application. 
	   //For current task, I don't need any. SO I am defining none
}
