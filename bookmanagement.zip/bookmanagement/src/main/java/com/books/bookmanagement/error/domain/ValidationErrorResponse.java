package com.books.bookmanagement.error.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class ValidationErrorResponse.
 */
public class ValidationErrorResponse implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8815288871632474880L;
	
	/** The message. */
	private String message;
	
	/** The violations. */
	private List<Violation> violations = new ArrayList<>();

	/**
	 * Gets the violations.
	 *
	 * @return the violations
	 */
	public List<Violation> getViolations() {
		return violations;
	}

	/**
	 * Sets the violations.
	 *
	 * @param violations the new violations
	 */
	public void setViolations(List<Violation> violations) {
		this.violations = violations;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
