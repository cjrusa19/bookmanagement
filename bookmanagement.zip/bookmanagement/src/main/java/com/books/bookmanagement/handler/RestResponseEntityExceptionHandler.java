package com.books.bookmanagement.handler;

import java.util.Locale;

import javax.persistence.NonUniqueResultException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.books.bookmanagement.error.domain.ValidationErrorResponse;
import com.books.bookmanagement.error.domain.Violation;
import com.books.bookmanagement.exception.BusinessException;

// TODO: Auto-generated Javadoc
/**
 * The Class RestResponseEntityExceptionHandler.
 */
@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	
	/** The message source. */
	@Autowired
	MessageSource messageSource;
    
    /**
     * Exception.
     *
     * @param exception the exception
     * @return the response entity
     */
    @ExceptionHandler(value = NonUniqueResultException.class)
    public ResponseEntity<Object> exception(NonUniqueResultException exception) {
       return new ResponseEntity<>(exception.getMessage(), HttpStatus.NOT_FOUND);
    }
    
    /**
     * Exception.
     *
     * @param exception the exception
     * @return the response entity
     */
    @ExceptionHandler(value = BusinessException.class)
    public ResponseEntity<Object> exception(BusinessException exception) {
       return new ResponseEntity<>(messageSource.getMessage(exception.getMessage(),exception.getArgs(), Locale.ENGLISH), HttpStatus.NOT_FOUND);
    }
    
    
    /**
     * Handle method argument not valid.
     *
     * @param ex the ex
     * @param headers the headers
     * @param status the status
     * @param request the request
     * @return the response entity
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
    		HttpHeaders headers, HttpStatus status, WebRequest request) {
    	ValidationErrorResponse error = new ValidationErrorResponse();
      for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
    	  error.setMessage("Validation Failed");
        error.getViolations().add(
          new Violation(fieldError.getField(), fieldError.getDefaultMessage()));
      }
        
    	return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
    
    /**
     * Handle constraint violation exception.
     *
     * @param e the e
     * @return the response entity
     */
    @ExceptionHandler(ConstraintViolationException.class)
    ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException e) {
      	return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }
    
}
