package com.books.bookmanagement.service;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.books.bookmanagement.dao.BookDAO;
import com.books.bookmanagement.domain.Book;
import com.books.bookmanagement.entity.BookPO;
import com.books.bookmanagement.exception.BusinessException;
import com.books.bookmanagement.mapper.DafaultDozerMapper;

@Service
public class BookManagementService implements IBookManagementService{
	Logger LOGGER = LogManager.getLogger(BookManagementService.class);
	
	@Autowired
	BookDAO bookDAO;
	
	/** The mapper. */
	@Autowired
	DafaultDozerMapper mapper;

	@Override
	public List<Book> getAllBooks() throws BusinessException {
		List<BookPO> bookPOList= bookDAO.findAll();
		List<Book> books = (List<Book>) this.mapper.mapPoToBoList(bookPOList, Book.class);
		LOGGER.debug("getAllBooks : "+books);
		if(CollectionUtils.isEmpty(books)) {
			throw new BusinessException("error.books.notavailable");
		}
		
		return books;
	}

	@Override
	public Book getBookByISBN(String isbn) throws BusinessException {
		BookPO bookPO = bookDAO.findByISBN(isbn);
		LOGGER.debug("getBookByISBN : "+bookPO);
		Book book = null;
		if(bookPO!=null) {
			book = this.mapper.mapPoToBo(bookPO, Book.class);
		}else {
			throw new BusinessException("error.nobook.exist", new String[] {isbn});
		}
		
		LOGGER.debug("getBookByISBN results : "+book);
		return book;
	}

	@Override
	public Book saveBook(Book book) throws BusinessException {
		BookPO esistingBookPO = bookDAO.findByISBN(book.getIsbn());
		if(esistingBookPO!=null) {
			throw new BusinessException("error.book.exist");
		}
		BookPO bookPO = this.mapper.mapBoToPo(book, BookPO.class);
		bookDAO.save(bookPO);
		Book dbBook = this.mapper.mapPoToBo(bookPO, Book.class);
		LOGGER.debug("saveBook results : "+dbBook);		
		return dbBook;
	}

	

}
