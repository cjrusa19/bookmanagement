package com.books.bookmanagement.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@MappedSuperclass
public abstract class BasePO implements Serializable {

	private static final long serialVersionUID = 8696039783520405168L;

	@Column(name = "CREATED_TS", nullable = false)
	private LocalDateTime createdTs;

	@Column(name = "UPDATED_TS", nullable = true)
	private LocalDateTime updatedTs;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "UPDATED_BY", nullable = true)
	private String updatedBy;

	public LocalDateTime getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(LocalDateTime createdTs) {
		this.createdTs = createdTs;
	}

	public LocalDateTime getUpdatedTs() {
		return updatedTs;
	}

	public void setUpdatedTs(LocalDateTime updatedTs) {
		this.updatedTs = updatedTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@PrePersist
	protected void onCreate() {
		this.createdTs = LocalDateTime.now();
		this.createdBy = "admin";
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedTs = LocalDateTime.now();
		this.updatedBy = "admin";
	}
}
