package com.books.bookmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.books.bookmanagement.domain.Book;
import com.books.bookmanagement.exception.BusinessException;
// TODO: Auto-generated Javadoc

/**
 * The Interface IBookManagementService.
 */
@Service
public interface IBookManagementService {
	
	/**
	 * Gets the all books.
	 *
	 * @return the all books
	 * @throws BusinessException the business exception
	 */
	List<Book> getAllBooks() throws BusinessException;
	
	/**
	 * Gets the book by ISBN.
	 *
	 * @param isbn the isbn
	 * @return the book by ISBN
	 * @throws BusinessException the business exception
	 */
	Book getBookByISBN(String isbn) throws BusinessException;
	
	/**
	 * Save book.
	 *
	 * @param book the book
	 * @return the book
	 * @throws BusinessException the business exception
	 */
	Book saveBook(Book book) throws BusinessException;
	
}
