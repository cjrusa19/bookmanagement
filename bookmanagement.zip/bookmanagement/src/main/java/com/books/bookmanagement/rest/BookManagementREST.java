package com.books.bookmanagement.rest;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.books.bookmanagement.domain.Book;
import com.books.bookmanagement.exception.BusinessException;
import com.books.bookmanagement.service.IBookManagementService;

/**
 * The Class BookManagementREST.
 */
@RestController
@RequestMapping("bookmanagement")
//@Validated
public class BookManagementREST {
 
	/** The logger. */
	Logger LOGGER = LogManager.getLogger(BookManagementREST.class);
	
	/** The book management service. */
	@Autowired
	IBookManagementService bookManagementService;

	/**
	 * Gets the books.
	 *
	 * @return the books
	 * @throws BusinessException the business exception
	 */
	@GetMapping(value = "/getbooks")
	public List<Book> getBooks() throws BusinessException {
		return bookManagementService.getAllBooks();
	}

	/**
	 * Gets the book by ISBN.
	 *
	 * @param isbn the isbn
	 * @return the book by ISBN
	 * @throws BusinessException the business exception
	 */
	@GetMapping(value = "/getBookByISBN/{isbn}")
	public Book getBookByISBN(@PathVariable("isbn") @Min(1) String isbn) throws BusinessException {
		LOGGER.debug("getBookByISBN input : "+isbn);
		return bookManagementService.getBookByISBN(isbn);
	}

	/**
	 * Creates the books.
	 *
	 * @param book the book
	 * @return the book
	 * @throws BusinessException the business exception
	 */
	@PostMapping(value = "/createbook")
	public Book createBooks( @RequestBody @Valid Book book) throws BusinessException {
		LOGGER.debug("createBooks input : "+book);
		return bookManagementService.saveBook(book);
	}
}
