package com.books.bookmanagement.domain;

import java.io.Serializable;

public class BaseDomain implements Serializable{

	private static final long serialVersionUID = 3734471462820856392L;

}
