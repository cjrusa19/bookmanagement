package com.books.bookmanagement.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="T_BOOK")
public class BookPO extends BasePO{

	private static final long serialVersionUID = -2433880793774263264L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long id;
	
	@Column(name="ISBN")
	private String isbn;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="AUTHOR")
	private String author;
	
	@Column(name="DATE_PUBLISHED")
	private Date datePublished;
	
	@Column(name="RATE")
	private Integer rate;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getDatePublished() {
		return datePublished;
	}
	public void setDatePublished(Date datePublished) {
		this.datePublished = datePublished;
	}
	public Integer getRate() {
		return rate;
	}
	public void setRate(Integer rate) {
		this.rate = rate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return " ID : "+this.id+
			   " Title : "+this.title+
			   " Author : "+this.author+
			   " ISBN : "+this.isbn+
			   " Date Published : "+this.datePublished+
			   " Rate : "+this.rate+
			   " Created By : "+this.getCreatedBy()+
		       " Created Timestamp : "+this.getCreatedTs()+
			   " Updated By : "+this.getUpdatedBy()+
			   " Updated Timestamp : "+this.getUpdatedTs();
	}

}
