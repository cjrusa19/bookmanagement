package com.books.bookmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Book extends BaseDomain implements Serializable{

	private static final long serialVersionUID = -4245983011060507073L;
	@NotEmpty(message = "{book.isbn.notnull}")
	@Size(min = 1, max = 30, message = "{book.isbn.size}")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "{error.isbn.alphanumeric}")
	private String isbn;
	@NotNull
	@Size(min = 1, max = 30)
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$",  message = "{error.title.alphanumeric}")
	private String title;
	@NotNull
	@Size(min = 1, max = 30)
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "{error.author.alphanumeric}")
	private String author;
	@NotNull
	private Date datePublished;
	private Integer rate;
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Date getDatePublished() {
		return datePublished;
	}

	public void setDatePublished(Date datePublished) {
		this.datePublished = datePublished;
	}

	public Integer getRate() {
		return rate;
	}

	public void setRate(Integer rate) {
		this.rate = rate;
	}


	@Override
	public String toString() {
		return "Title : "+this.title+
			   " Author : "+this.author+
			   " ISBN : "+this.isbn+
			   " Date Published : "+this.datePublished+
			   " Rate : "+this.rate;
	}
}
