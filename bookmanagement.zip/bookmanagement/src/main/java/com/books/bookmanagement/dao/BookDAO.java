package com.books.bookmanagement.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.books.bookmanagement.entity.BookPO;

@Repository
public interface BookDAO extends BaseDAO {
	@Query(value = "SELECT u FROM BookPO u where u.isbn=?1")
	BookPO findByISBN(String isbn);
}
