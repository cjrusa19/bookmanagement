Prerequisites 
Java 8
Gradle 

should be installed before inporting this project